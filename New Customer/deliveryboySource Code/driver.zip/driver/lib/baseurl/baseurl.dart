var baseUrl = "https://thecodecafe.in/hybrid_resturant/api/";
var imageBaseUrl = "https://thecodecafe.in/hybrid_resturant/";
var driverlogin = baseUrl + "driverlogin";
var delievery_boy_phone_verify = baseUrl + "delievery_boy_phone_verify";
var userRegistration = baseUrl + "userRegistration";
var driver_profile = baseUrl + "driver_profile";
var completed_orders = baseUrl + "completed_orders";
var ordersfortoday = baseUrl + "ordersfortoday";
var ordersfornextday = baseUrl + "ordersfornextday";
var dboy_status = baseUrl + "dboy_status";
var delivery_out = baseUrl + "delivery_out"; //cart_id
var delivery_accepted = baseUrl + "delivery_accepted"; //cart_id,user_signature
var delivery_completed =
    baseUrl + "delivery_completed"; //cart_id,user_signature
var termcondition = baseUrl + "termcondition";
var aboutus = baseUrl + "aboutus";
var support = baseUrl + "support";
var currency = baseUrl + "currency"; //cart_id,user_signature
var cashcollect = baseUrl + "cashcollect"; //cart_id,user_signature
var driverstatus = baseUrl + "driverstatus"; //cart_id,user_signature
var today_order_count = baseUrl + "today_order_count"; //cart_id,user_signature
var delivery_accepted_by_dboy =
    baseUrl + "delivery_accepted_by_dboy"; //cart_id,user_signature
var dboy_nextday_order =
    baseUrl + "dboy_nextday_order"; //cart_id,user_signature
var dboy_today_order = baseUrl + "dboy_today_order"; //cart_id,user_signature
var dboy_completed_order =
    baseUrl + "dboy_completed_order"; //cart_id,user_signature
var resturant_delivery_out =
    baseUrl + "resturant_delivery_out"; //cart_id,user_signature
var resturant_delivery_completed =
    baseUrl + "resturant_delivery_completed"; //cart_id,user_signature

//pharmancy

var pharmacy_dboy_today_order = baseUrl + "pharmacy_dboy_today_order";
var pharmacy_dboy_nextday_order = baseUrl + "pharmacy_dboy_nextday_order";
var pharmacy_dboy_completed_order = baseUrl + "pharmacy_dboy_completed_order";
var pharmacy_delivery_accepted_by_dboy =
    baseUrl + "pharmacy_delivery_accepted_by_dboy";
var pharmacy_today_order_count = baseUrl + "pharmacy_today_order_count";
var pharmacy_delivery_out = baseUrl + "pharmacy_delivery_out"; //not completed
var pharmacy_delivery_completed =
    baseUrl + "pharmacy_delivery_completed"; //not completed

//parcel api
var parcel_dboy_today_order = baseUrl + "parcel_dboy_today_order";
var parcel_dboy_completed_order = baseUrl + "parcel_dboy_completed_order";
var parcel_delivery_accepted_by_dboy =
    baseUrl + "parcel_delivery_accepted_by_dboy";
var parcel_today_order_count = baseUrl + "parcel_today_order_count";
var parcel_delivery_out = baseUrl + "parcel_delivery_out";
var parcel_delivery_completed = baseUrl + "parcel_delivery_completed";

var appname = 'GoMarket Dirver';
